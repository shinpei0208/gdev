# Xtensa configuration settings.

MAXPAGESIZE=0x1000
