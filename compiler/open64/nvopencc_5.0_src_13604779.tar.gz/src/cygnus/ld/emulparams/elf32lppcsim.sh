. ${srcdir}/emulparams/elf32lppc.sh
TEXT_START_ADDR=0x10000000
