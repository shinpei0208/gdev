. ${srcdir}/emulparams/sh.sh
OUTPUT_FORMAT="coff-shl"
