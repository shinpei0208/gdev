. ${srcdir}/emulparams/m32relf.sh
OUTPUT_FORMAT="elf32-m32rle"
