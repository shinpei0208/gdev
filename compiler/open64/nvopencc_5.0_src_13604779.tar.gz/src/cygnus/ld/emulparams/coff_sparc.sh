SCRIPT_NAME=sparccoff
OUTPUT_FORMAT="coff-sparc"
# following are dubious (borrowed from sparc lynx)
TARGET_PAGE_SIZE=0x1000
TEXT_START_ADDR=0
NONPAGED_TEXT_START_ADDR=0x1000
ARCH=sparc
