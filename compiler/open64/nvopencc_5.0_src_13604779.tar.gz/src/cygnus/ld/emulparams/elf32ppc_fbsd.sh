. ${srcdir}/emulparams/elf32ppc.sh
. ${srcdir}/emulparams/elf_fbsd.sh
