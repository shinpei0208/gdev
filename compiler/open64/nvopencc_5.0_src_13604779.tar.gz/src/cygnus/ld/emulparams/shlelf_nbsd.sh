. ${srcdir}/emulparams/shelf_nbsd.sh

OUTPUT_FORMAT="elf32-shl-nbsd"
