. ${srcdir}/emulparams/shelf32_nbsd.sh

OUTPUT_FORMAT="elf64-sh64-nbsd"
ELFSIZE=64

# We do not need .cranges
OTHER_SECTIONS=''
EXTRA_EM_FILE=
