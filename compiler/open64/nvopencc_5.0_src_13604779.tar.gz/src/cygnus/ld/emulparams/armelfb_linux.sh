. ${srcdir}/emulparams/armelf_linux.sh
OUTPUT_FORMAT="elf32-bigarm"
